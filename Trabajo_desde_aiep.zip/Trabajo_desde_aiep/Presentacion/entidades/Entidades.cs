﻿namespace Entidades
{
    public class ClienteEntidad
    {
        public int IdCliente { get; set; }
        public string Nombre { get; set; }
        public string Celular { get; set; }
        public string Correo { get; set; }
    }

    public class CasoEntidad
    {
        public int IdCaso { get; set; }
        public string Descripcion { get; set; }
        public int Estado { get; set; }
        public int IdCliente { get; set; }
    }

    public class TrabajadorEntidad
    {
        public int IdTrabajador { get; set; }
        public string Nombre { get; set; }
        public string Correo { get; set; }
        public string Celular { get; set; }
        public string Cargo { get; set; }
    }

    public class UsuarioEntidad
    {
        public int IdUsuario { get; set; }
        public string Correo { get; set; }
        public string Contrasena { get; set; }
        public string Cargo { get; set; }
    }
}