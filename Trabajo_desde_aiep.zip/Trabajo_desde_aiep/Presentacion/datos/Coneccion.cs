﻿using Microsoft.Data.SqlClient;

namespace TuProyecto
{
    public class Conexion
    {
        private string cadena =
        @"Server=SJAPLA3040041\SQLEXPRESS;
        Database=Tarea_aiep;
        User ID=sa;
        Password=User.sede;
        Encrypt=True;
        TrustServerCertificate=True;";

        public SqlConnection Conectar()
        {
            SqlConnection cn = new SqlConnection(cadena);
            cn.Open();
            return cn;
        }
    }
}